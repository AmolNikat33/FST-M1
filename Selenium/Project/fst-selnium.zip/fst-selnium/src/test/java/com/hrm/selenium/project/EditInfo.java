package com.hrm.selenium.project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class EditInfo {

	public static void main(String[] args) throws InterruptedException {
		WebDriverManager.chromiumdriver().setup();
		// Driver object reference
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		//  3. Logging into the site
		//Goal: Open the site and login with the credentials provided

		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.id("btnLogin")).click();
		
		String actualTitle = driver.getTitle();
		// assertTrue(title.contains("OrangeHRM"));
		String expectedTitle = "OrangeHRM";
		if (actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("Title Matched>>>YOUR IN HOME PAGE");
		else
			System.out.println("Title didn't match >>>YOUR NOT IN HOME PAGE");
		
		//5. Edit user information
		//Goal: Edit a user’s information
		
		driver.findElement(By.id("menu_pim_viewMyDetails")).click();
		driver.findElement(By.id("btnSave")).click();
		driver.findElement(By.id("personal_txtEmpLastName")).clear();
		driver.findElement(By.id("personal_txtEmpLastName")).sendKeys("editdone");
		driver.findElement(By.xpath("(//input[@type='radio'])[1]")).click();
		
		WebElement optn= driver.findElement(By.id("personal_cmbNation"));
		Thread.sleep(5000);
		Select select = new Select(optn);
		select.selectByIndex(82);
		
		driver.findElement(By.id("btnSave")).click();
		System.out.println("Edit page done.....Well done");

	}

}
