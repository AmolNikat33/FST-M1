package com.hrm.selenium.project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Directory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromiumdriver().setup();
		// Driver object reference
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// 3. Logging into the site
		// Goal: Open the site and login with the credentials provided

		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.id("btnLogin")).click();

		// 6. Verify that the “Directory” menu item is visible and clickable
		// Goal: Verify that the “Directory” menu item is visible and clickable
		driver.findElement(By.id("menu_directory_viewDirectory")).click();

		// driver.findElement(By.id("idOfElement")).isDisplayed();

		WebElement element = driver.findElement(By.id("searchBtn"));
		if (element.isDisplayed() && element.isEnabled()) {
			element.click();
		} else {
			System.out.println("Element is Visisble and clickable");
		}

		//driver.close();
	}

}
