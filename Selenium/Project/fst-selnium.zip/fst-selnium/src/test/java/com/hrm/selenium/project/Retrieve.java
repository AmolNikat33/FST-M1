package com.hrm.selenium.project;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Retrieve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromiumdriver().setup();
		// Driver object reference
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// 3. Logging into the site
		// Goal: Open the site and login with the credentials provided

		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.id("btnLogin")).click();
		driver.manage().window().maximize();
		
		
		//9. Retrieve emergency contacts
		//Goal: Login and retrieve the emergency contacts for the user
		driver.findElement(By.id("menu_pim_viewMyDetails")).click();
		
		driver.findElement(By.xpath("//a[text()='Emergency Contacts']")).click();
		
		WebElement table = driver.findElement(By.className("table hover"));
		        List<WebElement> rowsList = table.findElements(By.tagName("tr"));

		        List<WebElement> columnsList = null;

		       for (WebElement row : rowsList) {
		               columnsList = row.findElements(By.tagName("td"));

		                for (WebElement column : columnsList) {
		                       System.out.println("column text" + column.getText()+ ", "); // here is is just printing number of rows, like 1, 2
		               }

		        }
	}

}
