package com.hrm.selenium.project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Addqualifications {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromiumdriver().setup();
		// Driver object reference
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// 3. Logging into the site
		// Goal: Open the site and login with the credentials provided

		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.findElement(By.id("txtUsername")).sendKeys("orange");
		driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
		driver.findElement(By.id("btnLogin")).click();
		driver.manage().window().maximize();
		
		//7. Adding qualifications
		//Goal: Add employee qualifications
		driver.findElement(By.id("menu_pim_viewMyDetails")).click();
		driver.findElement(By.xpath("(//a[text()='Qualifications'])[2]")).click();
		driver.findElement(By.id("addWorkExperience")).click();
		
		driver.findElement(By.id("experience_employer")).sendKeys("IBM");
		driver.findElement(By.id("experience_jobtitle")).sendKeys("Automation Engineer");
		;
		
		driver.findElement(By.className("ui-datepicker-trigger")).click();
		
		Select select = new Select(driver.findElement(By.className("ui-datepicker-year")));
		select.selectByValue("2022");
		
		Select sel = new Select(driver.findElement(By.className("ui-datepicker-month")));
		sel.selectByValue("2");
		
		driver.findElement(By.xpath("//a[text()='7']")).click();
		driver.findElement(By.className("btnWorkExpSave")).click();
		
		
	}

}
