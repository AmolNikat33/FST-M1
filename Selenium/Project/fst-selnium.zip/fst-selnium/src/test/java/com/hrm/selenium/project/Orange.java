package com.hrm.selenium.project;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Orange {

	public static void main(String[] args) {

		WebDriverManager.chromiumdriver().setup();
		// Driver object reference
		WebDriver driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Open the browser
		driver.get("http://alchemy.hguy.co/orangehrm");
		
		// 1. Verify the website title
		String actualTitle = driver.getTitle();
		// assertTrue(title.contains("OrangeHRM"));
		String expectedTitle = "OrangeHRM";
		if (actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("Title Matched");
		else
			System.out.println("Title didn't match");
		
		
		//2. Get the url of the header image
		WebElement el =driver.findElement(By.xpath("//div[@id='divLogo']/img"));
	      //getAttribute() to get src of image
	    System.out.println("Src attribute is: "+ el.getAttribute("src"));
	}

}
